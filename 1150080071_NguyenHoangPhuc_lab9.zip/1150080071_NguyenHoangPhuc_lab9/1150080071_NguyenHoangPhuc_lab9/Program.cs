﻿using System;
using System.Windows.Forms;

namespace _1150080071_NguyenHoangPhuc_lab9
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
