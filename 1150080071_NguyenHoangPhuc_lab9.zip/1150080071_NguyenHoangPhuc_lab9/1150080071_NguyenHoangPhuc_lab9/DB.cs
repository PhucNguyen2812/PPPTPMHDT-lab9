﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using System.Data;

namespace _1150080071_NguyenHoangPhuc_lab9
{
   

    public static class Db
    {
        private const string CONN_STR ="Host=localhost;Port=5432;Database=quanlysach;Username=postgres;Password=123";

        public static NpgsqlConnection GetOpenConnection()
        {
            var conn = new NpgsqlConnection(CONN_STR);
            conn.Open();
            return conn;
        }
    }

}
