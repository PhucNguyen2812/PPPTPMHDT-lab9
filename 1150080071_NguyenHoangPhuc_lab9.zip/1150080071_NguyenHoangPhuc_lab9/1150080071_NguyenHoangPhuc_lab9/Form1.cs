﻿using System;
using System.Windows.Forms;
using Npgsql;
public partial class Form1 : Form

namespace _1150080071_NguyenHoangPhuc_lab9
{
    public partial class Form1 : Form
    {
        public Form1() { InitializeComponent(); }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDanhSachNxb();   
            txtMa.Focus();
        }

        private void LoadDanhSachNxb()
        {
            using (var conn = Db.GetOpenConnection())
            using (var cmd = new NpgsqlCommand("SELECT * FROM sp_hienthi_nxb()", conn))
            using (var rd = cmd.ExecuteReader())
            {
                lsvDanhSach.Items.Clear();
                while (rd.Read())
                {
                    string ma = rd.GetString(0);
                    string ten = rd.IsDBNull(1) ? "" : rd.GetString(1);
                    string dc = rd.IsDBNull(2) ? "" : rd.GetString(2);

                    var it = new ListViewItem(ma.Trim());
                    it.SubItems.Add(ten);
                    it.SubItems.Add(dc);
                    lsvDanhSach.Items.Add(it);
                }
            }
        }

        private void lsvDanhSach_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach.SelectedItems.Count == 0) return;
            var ma = lsvDanhSach.SelectedItems[0].SubItems[0].Text;
            HienThiChiTietNxb(ma);
        }

        private void HienThiChiTietNxb(string ma)
        {
            using (var conn = Db.GetOpenConnection())
            using (var cmd = new NpgsqlCommand("SELECT * FROM sp_chitiet_nxb(@p_ma)", conn))
            {
                cmd.Parameters.AddWithValue("p_ma", PadChar10(ma));

                using (var rd = cmd.ExecuteReader())
                {
                    txtMa.Text = txtTen.Text = txtDiaChi.Text = "";
                    if (rd.Read())
                    {
                        txtMa.Text = rd.GetString(0).Trim();
                        txtTen.Text = rd.IsDBNull(1) ? "" : rd.GetString(1);
                        txtDiaChi.Text = rd.IsDBNull(2) ? "" : rd.GetString(2);
                    }
                }
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            var ma = PadChar10(txtMa.Text);
            var ten = (txtTen.Text ?? "").Trim();
            var dc = (txtDiaChi.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(ma.Trim()))
            { MessageBox.Show("Nhập mã NXB!"); txtMa.Focus(); return; }

            using (var conn = Db.GetOpenConnection())
            using (var cmd = new NpgsqlCommand("SELECT sp_them_nxb(@ma,@ten,@dc)", conn))
            {
                cmd.Parameters.AddWithValue("ma", ma);
                cmd.Parameters.AddWithValue("ten", ten);
                cmd.Parameters.AddWithValue("dc", dc);

                int kq = Convert.ToInt32(cmd.ExecuteScalar());
                if (kq > 0)
                {
                    MessageBox.Show("Thêm thành công!");
                    LoadDanhSachNxb();
                    ClearInputs();
                }
                else MessageBox.Show("Mã NXB đã tồn tại!");
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            var ma = PadChar10(txtMa.Text);
            var ten = (txtTen.Text ?? "").Trim();
            var dc = (txtDiaChi.Text ?? "").Trim();

            if (string.IsNullOrWhiteSpace(ma.Trim()))
            { MessageBox.Show("Chọn/nhập mã NXB để sửa!"); return; }

            using (var conn = Db.GetOpenConnection())
            using (var cmd = new NpgsqlCommand("SELECT sp_sua_nxb(@ma,@ten,@dc)", conn))
            {
                cmd.Parameters.AddWithValue("ma", ma);
                cmd.Parameters.AddWithValue("ten", ten);
                cmd.Parameters.AddWithValue("dc", dc);

                int kq = Convert.ToInt32(cmd.ExecuteScalar());
                if (kq > 0)
                {
                    MessageBox.Show("Sửa thành công!");
                    LoadDanhSachNxb();
                    ClearInputs();
                }
                else MessageBox.Show("Không tìm thấy NXB để sửa!");
            }
        }
        private void btnXoa_Click(object sender, EventArgs e)
        {
            var ma = PadChar10(txtMa.Text);
            if (string.IsNullOrWhiteSpace(ma.Trim()))
            { MessageBox.Show("Chọn mã NXB để xóa!"); return; }

            if (MessageBox.Show($"Xóa NXB {ma.Trim()}?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;

            using (var conn = Db.GetOpenConnection())
            using (var cmd = new NpgsqlCommand("SELECT sp_xoa_nxb(@ma)", conn))
            {
                cmd.Parameters.AddWithValue("ma", ma);

                int kq = Convert.ToInt32(cmd.ExecuteScalar());
                if (kq > 0)
                {
                    MessageBox.Show("Xóa thành công!");
                    LoadDanhSachNxb();
                    ClearInputs();
                }
                else if (kq == -1)
                {
                    MessageBox.Show("Không thể xóa do đang bị ràng buộc bởi bảng Sách.",
                        "Lỗi ràng buộc", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("Không tìm thấy NXB để xóa!");
            }
        }

        private void btnReload_Click(object sender, EventArgs e) => LoadDanhSachNxb();

        private void ClearInputs()
        {
            txtMa.Text = txtTen.Text = txtDiaChi.Text = "";
            txtMa.Focus();
        }

        private static string PadChar10(string s)
        {
            s = (s ?? "").Trim();
            if (s.Length > 10) s = s.Substring(0, 10);
            return s.PadRight(10, ' ');
        }
    }
}
